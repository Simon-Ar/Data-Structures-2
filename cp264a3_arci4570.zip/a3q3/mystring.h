/*
 * mystring.h
 *
 *  Created on: Jan 31, 2019
 *      Author: Simon
 */

#ifndef MYSTRING_H_
#define MYSTRING_H_

#include <stdio.h>
#include <stdlib.h>

int str_length(char *);
int word_count(char *);
void lower_case(char *);
void trim(char *);

#endif /* MYSTRING_H_ */
