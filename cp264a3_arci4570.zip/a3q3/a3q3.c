/*
 * a3q3.c
 *
 *  Created on: Jan 31, 2019
 *      Author: Simon
 */

#include "mystring.h"

int main(int argc, char* args[]) {
	setbuf(stdout,NULL);
	char str[100] = "     This Is    a Test   ";
	printf("\nWord count:%d", word_count(str));
	printf("\nBefore trimming:\"%s\"", str);
	printf("\nlength:%d", str_length(str));
	trim(str);
	lower_case(str);
	printf("\nAfter trimming:\"%s\"", str);
	printf("\nlength:%d", str_length(str));
	return 0;
}
