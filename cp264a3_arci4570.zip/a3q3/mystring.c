/*
 * mystring.c
 *
 *  Created on: Jan 31, 2019
 *      Author: Simon
 */


#include "mystring.h"

int str_length(char *s) {
	char *p = s;
	int i=0;
	while (*p++ != '\0'){
		i++;
	}
	return i;
}

int word_count(char *s) {
	int count=0;
	char *p = s;
	while (*p++ != '\0'){
		if (*p++==' '){
			while (*p==' '){
				p++;
			}
			count++;
		}
	}
	return count;
}

void lower_case(char *s) {
	char *p = s;
	while (*p != '\0'){
		if ((*p>=65)&&(*p<=90)){
			*p=*p+32;
		}
		p++;
	}
}

void trim(char *s) {
	char *p = s;

	int index, i;

	index = 0;
	while(p[index] == ' '){
		index++;
	}

	i = 0;
	while(p[i + index] != '\0'){
		p[i] = p[i + index];
		while (p[i+index]==' ' && p[i+index+1]==' '){
			index++;
		}
		i++;
	}
	p[i] = '\0';

	i = 0;
	index = -1;
	while(p[i] != '\0')
	{
		if(p[i] != ' ' && p[i] != '\t' && p[i] != '\n')
		{
			index = i;
		}

		i++;
	}

	p[index + 1] = '\0';

}
