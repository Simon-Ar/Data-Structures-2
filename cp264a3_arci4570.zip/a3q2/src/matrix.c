/*
 * matrix.c
 *
 *  Created on: Jan 29, 2019
 *      Author: Simon
 */


//---------------------------------------------------------
void magic_square(int *m, int n) {
	/* assign 3X3 matrix to following values
     8     1     6
     3     5     7
     4     9     2
	 */
	int values[9] = { 8, 1, 6, 3, 5, 7, 4, 9, 2 };
	int i, len = n*n, *p = values;
	for (i = 0; i < len; i++) *m++ = *p++;
}


//---------------------------------------------------------
void display_matrix(int *m, int n) {
	int *p = m, i, j;
	for (i = 0; i < n; i++) {
		printf("\n");
		for (j = 0; j < n; j++) printf("%4d", *p++);
	}
	printf("\n");
}

//---------------------------------------------------------
int is_magic_square(int *m, int n) {
	//For diagonal elements
	int *p = m;
	int sum = 0;
	int row;
	int column;
	int flag = 0;
	for (row = 0; row < n; row++) {
		for (column = 0; column < n; column++) {
			if (row == column){
				sum = sum + *(p + row*n + column);
			}
		}
	}

	//For Rows
	for (row = 0; row < n; row++) {
		int sum1 = 0;
		for (column = 0; column < n; column++) {
			sum1 = sum1 + *(p + column*n + row);
		}
		if (sum == sum1){
			flag = 1;
		}
	}

	//For Columns
	for (row = 0; row < n; row++) {
		int sum2 = 0;
		for (column = 0; column < n; column++) {
			sum2 = sum2 + *(p + column*n + row);
		}
		if (sum == sum2){
			flag = 1;
		}
	}
	return flag;
}

//---------------------------------------------------------
void transpose_matrix(int *m1, int *m2, int n) {
	int *p = m1;
	int *q = m2;
	int i, j;
	for (i = 0; i < n; i++){
		for (j = 0; j < n; j++){
			*(q + i*n+ j) = *(p + j*n + i);

		}

	}
}

//---------------------------------------------------------
void multiply_matrix(int *m1, int *m2, int *m3, int n) {

	int *p = m1;
	int *q = m2;
	int *r = m3;
	int sum;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			for (int k = 0; k < n; k++) {
				sum = sum + *(p + i*n+ k)*(*(q + k*n+ j));
			}

			*(r+i*n+j) = sum;
			sum = 0;
		}
	}
}
