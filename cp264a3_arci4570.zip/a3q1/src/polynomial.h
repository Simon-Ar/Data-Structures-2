/*
 * polynomial.h
 *
 *  Created on: Jan 29, 2019
 *      Author: Simon
 */

#ifndef POLYNOMIAL_H_
#define POLYNOMIAL_H_

#include<stdio.h>
#include<stdlib.h>

float horner(float x, int n, float p[]);
float bisection(float a, float b, int n, float p[]);

// from a2q2
float horner(float x, int n, float p[])
{
	float value = 0;
	int i;
	for(i = 0; i < n; i++)
		value = value * x + *p++;
	return value;
}

//your bisection method implementation
float bisection(float a, float b, int n, float p[]){
	int max = 25;
	int i = 0;
	float c = 0;
	float tol = 0.000001;
	float root = 0;

	while (i <= max){ //limit iterations to prevent infinite loop
		c = (a + b)/2; //new midpoint
		if ((horner(c,n,p)==0)||((b-a)/2<tol)){  //solution found
			root = c;
			break;
		}
		i++;
		if (((horner(c,n,p)>0)&&(horner(a,n,p)>0))||((horner(c,n,p)<0)&&(horner(a,n,p)<0))){
			a = c;
		}else{
			b = c;
		}
	}
	return root;
}

#endif /* POLYNOMIAL_H_ */
