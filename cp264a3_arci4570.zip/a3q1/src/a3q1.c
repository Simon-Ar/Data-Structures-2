/*
 * a3q1.c
 *
 *  Created on: Jan 29, 2019
 *      Author: Simon
 */


#include "polynomial.h"

int main(int argc, char* args[]){

	setbuf(stdout,NULL);
	//get polynomial efficients from command line arguments
	if (argc <= 1) {
		printf("Need more than one arguments, e.g.: 1 2 3 4\n");
		return 0;
	}
	int i, n = argc-1;
	float a[n];
	for (i=0;i<n;i++) {
		a[i] = atof(args[i+1]);
	}

	// repetitive polynomial evaluation for user input of x value
	float c, d;
	do {
		//get x value from keyboard
		do {
			printf("Please enter a,b value (Ctrl+C or 0,0 to quit):\n");
			if (scanf("%f,%f", &c, &d) != 2) {
				printf("Invalid input\n");
			} else {
				break;
			}
			while(getchar() !='\n');
		} while (1);


		if ((c == 0) && (d == 0)) break;
		else {
			float pc = horner(c, n, a);
			float pd = horner(d, n, a);
			printf("p(%f)=%f\n", c, pc);
			printf("p(%f)=%f\n", d, pd);

			if (pc * pd <= 0) {
				printf("find root at: %f\n", bisection(c, d, n, a));
			}
			else {
				printf("have the same sign on both sides\n");
			}
		}
	} while (1);

	return 0;
}
