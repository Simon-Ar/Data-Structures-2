/*
 * markstats.c
 *
 *  Created on: Mar. 14, 2019
 *      Author: Simon
 */

#include "markstats.h"

void merge_tree(TNODE **rootp1, TNODE **rootp2) {
	TNODE *np = (TNODE *) malloc(sizeof(TNODE));
	while (*rootp1 != NULL){
		np = extract_smallest_node(rootp1);
		insert(rootp2,np->data.name,np->data.score);
	}

}

void merge_data(MARKS  *ds1, MARKS *ds2) {
	//merge_tree(ds1->bst,ds2->bst);
//	ds2->count += ds1->count;
	//while ()
	ds2->mean = (ds2->mean + ds1->mean)/2;
}

// the following are adapted from markstats.c of a7q2

void display_stats(MARKS *sd) {
  printf("\nstatistics summary\n");
  printf("%-15s%d\n", "count", sd->count);
  printf("%-15s%3.1f\n", "mean", sd->mean);
  printf("%-15s%3.1f\n", "stddev", sd->stddev);
}

void add_data(MARKS *sd, char *name, float score) {
  if (search(sd->bst, name) == NULL) {
    insert(&sd->bst, name, score);
    //update statistics summary by adding a new data
    int count = sd->count;
    float mean = sd->mean;
    float stddev = sd->stddev;
    sd->count = count + 1;
    sd->mean =  (mean*count + score) / (count+1);
    sd->stddev = sqrt(score*score/(count+1.0) + (stddev * stddev + mean * mean) * (count/(count+1.0)) - sd->mean * sd->mean );
  } else
    printf("record exit");
}

void remove_data(MARKS *sd, char *name) {
  TNODE *np = NULL;
  if ( (np = search(sd->bst, name)) != NULL) {
    float score = np->data.score;
    delete(&sd->bst, name);

    //update statistics summary after removing an old one
    int count = sd->count;
    float mean = sd->mean;
    float stddev = sd->stddev;
    sd->count = count - 1;
    sd->mean =  (mean*count - score) / (count-1.0);
    sd->stddev = sqrt( (stddev * stddev + mean * mean) * (count/(count-1.0)) - score*score/(count-1.0) - sd->mean * sd->mean );
  } else
    printf("record not exit");
}

void import_data(MARKS *ds, char *filename) {
  char line[40], name[20];
  FILE *fp = fopen(filename, "r");
  char *result = NULL;
  char delimiters[] = ",\n";
  float score = 0;
  int count = 0;
  float mean =0, stddev = 0;

  if (fp == NULL) {
    perror("Error while opening the file.\n");
    exit(EXIT_FAILURE);
  }

  while (fgets(line, sizeof(line), fp) != NULL) {
    result = strtok(line, delimiters);
    if (result) {
      strcpy(name, result);
      result = strtok(NULL, delimiters);
      score = atof(result);
      count++;
      mean += score;
      stddev += score * score;
      insert(&ds->bst, name, score);
    }
  }

  ds->count = count;
  mean /= count;
  ds->mean = mean;
  ds->stddev = sqrt(stddev/count - mean*mean);

  fclose(fp);
}

void report_data(MARKS *sd, char *filename) {
  FILE *fp = fopen(filename, "w");
  fprintf(fp, "grade report\n");
  print_to_file(sd->bst, fp);
  fprintf(fp, "\nsimple statistics summary\n");
  fprintf(fp, "%-15s%d\n", "count", sd->count);
  fprintf(fp, "%-15s%3.1f\n", "mean", sd->mean);
  fprintf(fp, "%-15s%3.1f\n", "stddev", sd->stddev);
  fclose(fp);
}

void print_to_file(TNODE *root, FILE *fp) {
  if (root) {
    if (root->left) print_to_file(root->left, fp);
    fprintf(fp, "%-15s%3.1f%4c\n", root->data.name, root->data.score, letter_grade(root->data.score));
    if (root->right) print_to_file(root->right, fp);
  }
}

char letter_grade(float s){
  char r = 'F';
  if (s >= 85) r = 'A';
  else if (s >= 70) r = 'B';
  else if (s >= 60) r = 'C';
  else if (s >= 50) r = 'D';
  else r = 'F';
  return r;
}
