/*
 * avl.c
 *
 *  Created on: Mar. 14, 2019
 *      Author: Simon
 */


#include "avl.h"

// A utility functions

int max(int a, int b)
{
	return (a > b)? a : b;
}

int height(TNODE *np){
	if(np == NULL)
		return 0;
	else
		return np->height;
}

int balance_factor(TNODE* np) {
	if(np == NULL)
		return 0;
	else
		return height(np->left)-height(np->right);
}

int is_avl(TNODE *root) {
	int is_avl=1;
	if (root == NULL){
		return is_avl;
	} else if (balance_factor(root) >1){
		is_avl= 0;
	}
	is_avl = balance_factor(root->left) + balance_factor(root->right);
	if (is_avl<2)
		is_avl = 0;
	return is_avl;
}

TNODE *rotate_right(TNODE *y){
	TNODE *x = y->left;
	TNODE *T2 = x->right;
	x->right = y;
	y->left = T2;

	y->height = max(height(y->left), height(y->right))+1;
	x->height = max(height(x->left), height(x->right))+1;

	return x;
}

TNODE *rotate_left(TNODE *x){
	TNODE *y = x->right;
	TNODE *T2 = y->left;

	y->left = x;
	x->right = T2;


	x->height = max(height(x->left), height(x->right))+1;

	y->height = max(height(y->left), height(y->right))+1;

	return x;
}

void insert(TNODE **rootp, char *name, float score){
	  TNODE *np = (TNODE *) malloc(sizeof(TNODE));
	  if (np == NULL) return;
	  strcpy(np->data.name, name);
	  np->data.score = score;
	  np->height = 1;
	  np->left = NULL;
	  np->right = NULL;

	  // 1. Perform the normal BST insertion
	  if (*rootp == NULL) {
	    *rootp = np;
	    return;
	  }

	  TNODE *root = *rootp;
	  if (strcmp(name, root->data.name) < 0 )
	    insert(&root->left, name, score);
	  else if (strcmp(name, root->data.name) > 0 )
	    insert(&root->right, name, score);
	  else return ;

	// 2. update height of this root node
	    root->height = 1 + max(height(root->left),
	                           height(root->right));

	    /* 3. Get the balance factor of this ancestor
	          node to check whether this node became
	          unbalanced */
	    int balance = balance_factor(root);

	    // If this node becomes unbalanced, then
	    // there are 4 cases

	    // Left Left Case
	    if (balance > 1 && name < root->left->data.name)
	        rotate_right(root);

	    // Right Right Case
	    if (balance < -1 && name > root->right->data.name)
	        rotate_left(root);

	    // Left Right Case
	    if (balance > 1 && name > root->left->data.name)
	    {
	        root->left =  rotate_left(root->left);
	        rotate_right(root);
	    }

	    // Right Left Case
	    if (balance < -1 && name > root->right->data.name)
	    {
	        root->right = rotate_right(root->right);
	        rotate_left(root);
	    }

}

void delete(TNODE **rootp, char *name){
	TNODE *root = *rootp;
	TNODE* np;

	if (root == NULL) return;

	if (strcmp(name, root->data.name) == 0) {
		if (root->left == NULL && root->right == NULL) {
			free(root);
			*rootp = NULL;
		} else if (root->left != NULL && root->right == NULL) {
			np = root->left;
			free(root);
			*rootp = np;
		} else if (root->left == NULL && root->right != NULL) {
			np = root->right;
			free(root);
			*rootp = np;
		} else if (root->left != NULL && root->right != NULL) {
			np = extract_smallest_node(&root->right);
			np->left = root->left;
			np->right = root->right;
			free(root);
			*rootp = np;
		}
	} else {
		if (strcmp(name, root->data.name) < 0) {
			delete(&root->left, name);
		} else {
			delete(&root->right, name);
		}
	}

	// If the tree had only one node then return
	if (*rootp == NULL) return;

	root = *rootp;

	// STEP 2: update the this root node's height

	root->height = 1 + max(height(root->left),
			height(root->right));
	// STEP 3: get the balance factor of this root node

	int balance = balance_factor(root);


	// STEP 4: re-balance if not balanced


	// Left Left Case
	if (balance > 1 && balance_factor(root->left) >= 0){
		rotate_right(root);
		return;
	}

	// Left Right Case
	if (balance > 1 && balance_factor(root->left) < 0){
		root->left =  rotate_left(root->left);
		rotate_right(root);
		return;
	}

	// Right Right Case
	if (balance < -1 && balance_factor(root->right) <= 0){
		rotate_left(root);
		return;
	}

	// Right Left Case
	if (balance < -1 && balance_factor(root->right) > 0){
		root->right = rotate_right(root->right);
		rotate_left(root);
		return;
	}

}


// following functions are from bst.c of a7q2

TNODE *extract_smallest_node(TNODE **rootp) {
	TNODE *tnp = *rootp;
	TNODE *parent = NULL;
	if (tnp == NULL) {
		return NULL;
	} else {
		while (tnp->left) {
			parent = tnp;
			tnp = tnp->left;
		}
		if (parent == NULL)
			*rootp = tnp->right;
		else
			parent->left = tnp->right;
		tnp->left = NULL;
		tnp->right = NULL;
		return tnp;
	}
}


TNODE *search(TNODE *root, char *name) {
	TNODE *tp = root;
	while (tp) {
		if (strcmp(name, tp->data.name) == 0) {
			return tp;
		}
		else if (strcmp(name, tp->data.name) < 0)
			tp = tp->left;
		else
			tp = tp->right;
	}
	return NULL;
}

void clean_tree(TNODE **rootp) {
	if (*rootp) {
		TNODE *np = *rootp;
		if (np->left)
			clean_tree(&np->left);
		if (np->right)
			clean_tree(&np->right);
		free(np);
	}
	*rootp = NULL; ;
}

void display_inorder(TNODE *root) {
	if (root) {
		if (root->left) display_inorder(root->left);
		printf("%-22s%3.1f\n", root->data.name, root->data.score);
		if (root->right) display_inorder(root->right);
	}
}

void display_tree(TNODE *root, int prelen) {
	if (root) {
		int i;
		for (i = 0; i < prelen; i++)
			printf("%c", ' ');
		printf("%s", "|___");
		printf("%s %3.1f %d\n", root->data.name, root->data.score, root->height);
		display_tree(root->right, prelen + 4);
		display_tree(root->left, prelen + 4);
	}
}
