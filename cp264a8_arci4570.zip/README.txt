Name:
ID:
Email:
WorkID: cp264a8
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1 
1. height, balance_factor, is_avl functions     [5/5/] 
2. rotate_left, rotate_right functions          [5/5/] 
3. insert function                              [1/5/]
4. delete function                              [1/5/]

Q2
1. merge tree function                          [5/5/]
2. merge data function, stats aggregation       [1/5/] 

Total:                                         [17/30/]

Test result:

Q1 output: (copy the screen output of your test run) 


Q2 output: (copy the screen output of your test run) 



 