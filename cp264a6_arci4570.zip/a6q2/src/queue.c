/*
 * queue.c
 *
 *  Created on: Mar. 2, 2019
 *      Author: Simon
 */

#include "queue.h"

void enqueue(QNODE **frontp, QNODE **rearp, int val){
	QNODE *np = malloc(sizeof(*np));
	if (*frontp == NULL){
		np->data = val;
		np->next = NULL;
		*frontp = np;
		*rearp = np;
	} else{
		np->data = val;
		np->next = NULL;
		(*rearp)->next = np;
		*rearp = np;
	}
}

int dequeue(QNODE **frontp, QNODE **rearp) {
	QNODE *current = *frontp;
	if (*frontp == NULL){
		return NULL;
	} else{
		*frontp = current->next;
		return current->data;
	}
}

int peek(QNODE *front) {
	if (front == NULL){
		return NULL;
	}else
		return front->data;

}

void clean(QNODE **frontp, QNODE **rearp){
	*frontp = NULL;
	*rearp = NULL;
}
