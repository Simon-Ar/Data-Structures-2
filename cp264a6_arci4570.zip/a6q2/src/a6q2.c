/*
 Name        : a6q2.c -- test driver program
 Author      : HBF
 Version     : 2019-02-10
 */
#include "queue.h"

int main(int argc, char* args[]) {
	setbuf(stdout,NULL);
	QNODE *front = NULL, *rear = NULL;
	int i=0;
	for (i=1; i<=12; i++) {
		enqueue(&front, &rear, i);
	}

	printf("%d ", peek(front));
	dequeue(&front, &rear);
	printf("%d ", dequeue(&front, &rear));
	printf("\n");

	while (front != NULL) {
		printf("%d ", dequeue(&front, &rear));
	}

	for (i=1; i<=12; i++) {
		enqueue(&front, &rear, i);
	}
	clean(&front, &rear);

	return 0;
}
