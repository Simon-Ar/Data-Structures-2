/*
 * expeval.h
 *
 *  Created on: Mar. 2, 2019
 *      Author: Simon
 */

#ifndef EXPEVAL_H_
#define EXPEVAL_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* node structure for postfix expression by queue and evaluation by stack */
typedef struct node {
    int data; // data can be int operant or a operator
    int type; // 0: int operant; 1:operator; 3: for parenthesis
    struct node *next;
} NODE;

/* convert infix expression string to postfix representation by queue */
void infix_to_postfix(char *infixstr, NODE **frontp, NODE **rearp);

/* evaluate postfix and return its value, use auxiliary stack */
int evaluate_postfix(NODE **frontp, NODE **rearp);

/* following utility functions are given in help */
int get_priority(char opr);
int is_operator(char op);
int is_symbol(char s);

/* the following functions are adapted from a6q1, a6q2, and a6q3 */
NODE *new_node(int data, int type);
void display_forward(NODE *start);
void clean(NODE **startp);
NODE *dequeue(NODE **frontp, NODE **rearp);
void enqueue(NODE **frontp, NODE **rearp, NODE *np);
void push(NODE **topp, NODE *np);
NODE *pop(NODE **topp);


#endif /* EXPEVAL_H_ */
