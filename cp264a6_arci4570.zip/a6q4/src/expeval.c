/*
 * expeval.c
 *
 *  Created on: Mar. 2, 2019
 *      Author: Simon
 */

#include "expeval.h"

void infix_to_postfix(char *infixstr, NODE **frontp, NODE **rearp) {
	NODE *top=NULL;
	char *p = infixstr;
	int  num = 0;
	while (*p) {
		if (*p >= '0' && *p <= '9'){
			num = *p-'0';
			while ((*(p+1) >= '0' && *(p+1) <= '9')) { // this is to continue to scan in case the number has more digits
				num = num*10 + *(p+1)-'0';
				p++;
			}
			enqueue(frontp, rearp, new_node(sign*num, 0));
		}else if (*p == '(') {
			push(&top, new_node('(', 3));
		} else if (*p == ')') {
			.........
		}  else if  (is_operator(*p))  {
			...........
		}
		p++;
	}while (top) {
		enqueue(frontp, rearp, pop(&top));
	}
}


int evaluate_postfix(NODE **frontp, NODE **rearp) {
	// new program for a6q4
}

int get_priority(char op) {
	if (op == '/' || op == '*' || op == '%') return 1;
	else if (op == '+' || op == '-') return 0;
	return 0;
}

int is_operator(char op) {
	if (op == '/' || op == '*' || op == '%' || op == '+' || op == '-')
		return 1;
	else
		return 0;
}

int is_symbol(char s) {
	if (!is_operator(s) && !isdigit(s) && s != ')' && s != '(') {
		return 1;
	} else
		return 0;
}


NODE *new_node(int data, int type) {
	NODE *np = (NODE *) malloc(sizeof(NODE));
	np->data = data;
	np->type = type;
	np->next = NULL;
	return np;
}

void push(NODE **topp, NODE *np) {
	if (*topp == NULL){
		*topp = np;
	} else{
		np->next = *topp;
		*topp = np;
	}
}

NODE *pop(NODE **topp) {
	NODE *current = *topp;
	if (*topp == NULL){
		return NULL;
	} else{
		*topp = current->next;
		return current;
	}
}

void enqueue(NODE **topp, NODE **bottom, NODE *np) {
	if (*topp == NULL){
		np->next = NULL;
		*topp = np;
		*bottom = np;
	} else{
		np->next = NULL;
		(*bottom)->next = np;
		*bottom = np;
	}}

NODE *dequeue(NODE **frontp, NODE **rearp) {
	NODE *current = *frontp;
	if (*frontp == NULL){
		return NULL;
	} else{
		*frontp = current->next;
		return current;
	}
}

void display_forward(NODE *start) {
	setbuf(stdout,NULL);
	NODE *ptr=start;
	while (ptr != NULL){
		printf("%c ",ptr->data);
		ptr=ptr->next;
	}
}

void clean(NODE **startp) {
	*startp = NULL;
}

