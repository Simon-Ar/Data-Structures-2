/*
 * stack.c
 *
 *  Created on: Mar. 2, 2019
 *      Author: Simon
 */


#include "stack.h"

void push(SNODE **topp, int value) {
	SNODE *np = malloc(sizeof(*np));
	if (*topp == NULL){
		np->data = value;
		np->next = NULL;
		*topp = np;
	} else{
		np->data = value;
		np->next = *topp;
		*topp = np;
	}
}


void pop(SNODE **topp) {
	SNODE *current = *topp;
	if (*topp == NULL){
	} else{
		*topp = current->next;
	}
}

int peek(SNODE *top) {
	if (top == NULL){
		return NULL;
	}else
		return top->data;
}

void clean(SNODE **topp) {
	*topp = NULL;
}
