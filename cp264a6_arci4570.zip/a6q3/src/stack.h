/*
 * stack.h
 *
 *  Created on: Mar. 2, 2019
 *      Author: Simon
 */

#ifndef STACK_H_
#define STACK_H_

#include <stdio.h>
#include <string.h>
#include <malloc.h>
#include <ctype.h>

typedef struct node {
  int data;
  struct node *next;
} SNODE;

void push(SNODE **topp, int value);
void pop(SNODE **topp);
int peek(SNODE *);
void clean(SNODE **topp);

#endif /* STACK_H_ */
