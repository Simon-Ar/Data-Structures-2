/*
 * dllist.c
 *
 *  Created on: Feb 15, 2019
 *      Author: Simon
 */

#include "dllist.h"

NODE *new_node(char data) {
	NODE *np = malloc(sizeof(*np));
	np->data = data;
	np->next = NULL;
	np->prev = NULL;
	return np;
}

void display_forward(NODE *np) {
	setbuf(stdout,NULL);
	NODE *ptr=np;
	while (ptr != NULL){
		printf("%c ",ptr->data);
		ptr=ptr->next;
	}
}

void display_backward(NODE *np) {
	setbuf(stdout,NULL);

	NODE *ptr=np;
	while (ptr != NULL){
		printf("%c ",ptr->data);
		ptr=ptr->prev;
	}
}

void insert_start(NODE **startp, NODE **endp, NODE *new_np) {
	if (*startp == NULL){
		new_np->next = NULL;
		new_np->prev = NULL;
		*startp = new_np;
		*endp = new_np;
	} else{
		new_np->prev = NULL;
		new_np->next = *startp;
		(*startp)->prev = new_np;
		*startp = new_np;
	}
}

void insert_end(NODE **startp, NODE **endp, NODE *new_np) {
	if (*endp == NULL){
		new_np->next = NULL;
		new_np->prev = NULL;
		*startp = new_np;
		*endp = new_np;
	} else{
		new_np->next = NULL;
		new_np->prev = *endp;
		(*endp)->next = new_np;
		*endp = new_np;
	}
}

void delete_start(NODE **startp, NODE **endp) {
	NODE *ptr = *startp;
	if (ptr != NULL) {
		if (ptr == *endp) {
			*startp = NULL;
			*endp = NULL;
		} else {
			*startp = ptr->next;// set the new start node
			(*startp)->prev = NULL;
		}free(ptr);    // free the old start node}}
	}
}

void delete_end(NODE **startp, NODE **endp) {
	NODE *ptr = *endp;
	if (ptr != NULL) {
		if (ptr == *startp) {
			*startp = NULL;
			*endp = NULL;
		} else {
			*endp = ptr->prev;// set the new start node
			(*endp)->next = NULL;
		}free(ptr);    // free the old start node}}
	}
}


void clean(NODE **startp, NODE **endp) {
	*startp = NULL;
	*endp=NULL;
}
