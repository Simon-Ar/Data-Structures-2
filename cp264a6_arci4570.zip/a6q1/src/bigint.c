/*
 * bigint.c
 *
 *  Created on: Feb. 27, 2019
 *      Author: Simon
 */

#include "dllist.h"
#include "bigint.h"

BIGINT add(BIGINT op1, BIGINT op2) {
	double x = 0;
	double y = 0;
	int digit = 0;
	NODE *currentA = op1.end;
	NODE *currentB = op2.end;

	while ((currentA != NULL) && (currentB != NULL)){
		if (currentA != NULL){
			x += currentA->data *(pow(10,digit));
			currentA = currentA->prev;
		} if (currentB != NULL){
			y += currentB->data *(pow(10,digit));
			currentB = currentB->prev;
		}
		digit++;
	}
	char sum[digit];
	sprintf(sum, "%.0f", x+y);
	char *psum = sum;
	return (bigint(psum));
}

BIGINT Fibonacci(int n){
    double prev = 1;
    double current = 1;
    double total = 1;
    int digit = 0;

    for (int i = 3; i <= n; ++i){
        total = current + prev;
        prev = current;
        current = total;
    }
    double temp = total;
    while (temp >1){
    	digit++;
    	temp /=10;
    }
	char sum[digit];
	sprintf(sum, "%.0f", total);
	char *psum = sum;
	return (bigint(psum));

}
BIGINT bigint(char *p) {
	BIGINT bn = {0};
	if (p == NULL)
		return bn;
	else if (!(*p > '0' && *p <= '9')) {
		return bn;
	}
	while (*p) {
		if (*p >= '0' && *p <= '9' ){
			insert_end(&bn.start, &bn.end, new_node(*p -'0'));
		} else {
			clean_bigint(&bn);
			insert_end(&bn.start, &bn.end, new_node('0'));
			break;
		}
		p++;
	}
	return bn;
}

void display_bigint(BIGINT bignumber) {
	setbuf(stdout,NULL);
	NODE *ptr = bignumber.start;
	while ( ptr != NULL) {
		printf("%d", ptr->data);
		ptr = ptr->next;
	}
}

void clean_bigint(BIGINT *bignumberp) {
	clean(&bignumberp->start, &bignumberp->end);
}

