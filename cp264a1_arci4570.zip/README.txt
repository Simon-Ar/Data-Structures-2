Name: Simon Arcila
ID: 130804570
Email: arci4570@mylaurier.ca
WorkID: cp264a1
Statement: I claim that the enclosed submission is my individual work 

Check list, self-evaluation/marking, marking scheme:
Note: fill self-evaluation for each of the following brackets. The field format is [self-evaluation / total marks / marker's evaluation]. For example, you put your self-evaluation, say 2, like [2/2/]. If marker gives different evaluation value say 1, it will show [2/2/1] in the marking report. 

Evaluation: [self-evaluation/total/marker-evaluation]

Q1
1. prompt for input                   [3/3/]  
2. input upper/lower case             [3/3/]
3. robust for invalid input           [2/2/] 
4. repeat and quit                    [2/2/] 

Q2
1. command line argument              [3/3/]
2. Correctness of computing results   [3/3/]
3. robust for invalid input           [2/2/] 
4. output format                      [2/2/]

Q3
1. prompt for input                   [3/3/]
2. correctness of solution            [3/3/]
3. robust for invalid input           [2/2/] 
4. output format                      [2/2/] 

Total:                               [30/30/]