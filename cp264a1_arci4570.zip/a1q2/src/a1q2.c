/*
 * a1q2.c
 *
 *  Created on: Jan 16, 2019
 *      Author: Simon
 */

#include<stdio.h>
#include<stdlib.h>

int main(int argc,char *args[]){
	setbuf(stdout,NULL);
	int result=1;
	int i=1;
	int n =  atoi(args[1]);
	while(i<= n){
		result*=i;
		if (i%4==0){
			printf("%11d\n",result);
		} else{
			printf("%11d",result);
		}
		++i;
	}
	return 0;
}
