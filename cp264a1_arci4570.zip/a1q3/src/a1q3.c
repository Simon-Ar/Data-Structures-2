/*
 * a1q3.c
 *
 *  Created on: Jan 16, 2019
 *      Author: Simon
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(int argc, char *args[]){
	setbuf(stdout,NULL);
	float a,b,c;
	int inputCheck;
	float root1;
	float root2;
	char line[256];

	printf("Enter the coefficients: ");
	fgets(line, sizeof line, stdin);
	inputCheck = sscanf(line,"%f,%f,%f",&a,&b,&c);

	while (!((a==0) && (b == 0) && (c ==0))){

		if (!inputCheck){
			printf("Invalid input.\n");
		}else if (a==0){
			printf("The equation is not quadratic.\n");
		} else if ((b*b)-(4*a*c)==0){
			root1 = (-b + sqrt((b*b)-(4*a*c)))/2*a;
			printf("The equation has two equal roots: \n%f\n",root1);
		} else if ((b*b)-(4*a*c)<0){
			float real;
			float imagine;

			real = -b/(2*a);
			imagine = sqrt(-((b*b)-(4*a*c)))/2*a;
			printf("The equation has two complex roots: \n%f+i%f\n",real,imagine);

			real = -b/(2*a);
			imagine = sqrt(-((b*b)-(4*a*c)))/2*a;
			printf("%f-i%f\n",real,imagine);
		} else if ((b*b)-(4*a*c)>0){
			root1 = (-b + sqrt((b*b)-(4*a*c)))/2*a;
			root2 = (-b - sqrt((b*b)-(4*a*c)))/2*a;
			printf("The equation has two distinct roots: \n%f\n%f\n",root1,root2);
		}

		printf("Enter the coefficients: ");
		fgets(line, sizeof line, stdin);
		inputCheck = sscanf(line,"%f,%f,%f",&a,&b,&c);

	}
	return 0;
}
