/*
 * a1q1.c
 *
 *  Created on: Jan 16, 2019
 *      Author: Simon
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *args[]){
	setbuf(stdout, NULL);
	char letter;
	do{
		printf("Enter a letter ('*' to quit):  ");
		scanf(" %c",&letter);
		if (letter>='A'||letter<='Z'){
			printf("%c %d %c\n",letter, letter, letter+32);
		}else if (letter>='a'||letter<='z'){
			printf("%c %d %c\n", letter,letter,letter-32);
		}
	} while (letter != '*');
	return(0);
}
