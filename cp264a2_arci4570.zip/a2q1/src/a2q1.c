/*
 * a2q1.c
 *
 *  Created on: Jan 25, 2019
 *      Author: Simon
 */

#include <stdio.h>
#include <time.h>

int *la;
int *ha;

int iterative_fibonacci(int n)
{
    if (&n < la) la = &n;  // to the memory address of local variable for memory usage.
    int temp = 1;
    int current = 1;
    int total = 1;

    for (int i = 3; i <= n; ++i)
    {
        total = current + temp;
        temp = current;
        current = total;
    }
    return total;
}

int recursive_fibonacci(int n) {
    if (&n < la) la = &n;
    int total=0;
    if (n==1){
    	return 1;
    }else if (n==0){
    	return 0;
    } else {
    	total = recursive_fibonacci(n-1) + recursive_fibonacci(n-2);
    	return total;
    	}
    }


int main(){
	setbuf(stdout,NULL);
    int i=0, n=40;
    clock_t t1, t2;

    printf("Iterative algorithm measurement:\n");
    //memory measuring for iterative_fibonacci
    ha = &i;
    la = ha;
    printf("iterative_fibonacci(%d): %d\n", n, iterative_fibonacci(n));
    printf("high address: %lu\n", ha);
    printf("low address: %lu\n", la);
    int memory_span1 = (unsigned long) ha - (unsigned long) la;
    printf("memory span: %d\n",memory_span1);

    //run time measuring for iterative_fibonacci
    int m1 = 500000;
    t1=clock();
    for (i=0; i< m1; i++) {
        iterative_fibonacci(n);
    }
    t2=clock();
    double time_span1 = (double) t2-t1;
    printf("time_span(iterative_fibonacci(%d) for %d times): %0.1f (ms)\n", n, m1, time_span1);

    printf("Recursive algorithm measurement:\n");
    //memory measuring for iterative_fibonacci
    i=0;
    ha = &i;
    la = ha;
    printf("recursive_fibonacci(%d): %d\n", n, recursive_fibonacci(n));
    printf("high address: %lu\n", ha);
    printf("low address: %lu\n", la);
    int memory_span2 = (unsigned long) ha - (unsigned long) la;
    printf("memory span: %d\n",memory_span2);

    //run time measuring for recursive_fibonacci
    int m2 = 10;
    t1=clock();
    for (i=0; i< m2; i++) {
        recursive_fibonacci(n);
    }
    t2=clock();
    double time_span2 = (double) t2-t1;
    printf("time_span(recursive_fibonacci(%d) for %d times): %0.1f (ms)\n", n, m2, time_span2);

    // comparison
    printf("\nComparison of recursive and iterative algorithms:\n");

    printf("memory_span(recursive_fibonacci(%d))/memory_span(iterative_fibonacci(%d)): %0.1f\n", n, n, ((double) memory_span2)/memory_span1);

    printf("time_span(recursive_fibonacci(%d))/time_span(iterative_fibonacci(%d)): %0.1f\n", n, n, (time_span2/time_span1)*(m1/m2));

    return 0;
}
