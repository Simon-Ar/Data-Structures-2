/*
 * a2q2.c
 *
 *  Created on: Jan 25, 2019
 *      Author: Simon
 */

#include<stdio.h>
#include<stdlib.h>

float horner(float x, int n, float a[]){

    int r = 0;
    int i;
    for (i = 0; i < n; i++){
        r = r*x+a[i];
    }
    return r;
}

int main(int argc, char* args[]){

	setbuf(stdout,NULL);

    //get polynomial efficients from command line arguments
    if (argc <= 1) {
        printf("Need more than one arguments, e.g.: 1 2 3 4\n");
        return 0;
    }
    int i, n = argc-1;
    // declare float array data structure for coefficients
    float a[n];

    // read command line arguments convert them to floating numbers atof(args[i+1]);
    for (i=0;i<n;i++){
    	a[i]=atof(args[i+1]);
    }

    // repetitive polynomial evaluation for user input of x value
    float x = 0.0;
    do {
        //get x value from keyboard
        do {
            // handle invalid input
            printf("Please enter x value (Ctrl+C or 999 to quit):\n");
            if (scanf("%f", &x) != 1) {
                printf("Invalid input\n");
            } else {
                break;
            }
            // while(getchar() !='\n') ;
            do {
                if (getchar() == '\n') break;
            } while (1);
        } while (1);

        // escape when input 999
        if (x==999){
        	break;
        }
        // print the polynomial expression
        // use x^n to denote x raised to the n-th power
        // use %.1f format for floating number
        // print polynomial by calling horner(x, n, a)

        float result = horner(x,n,a);
        int pow = n-1;
        for (int coef=0;coef<n-1;coef++){
        	printf("(%.1f * %.1f^%d) + ",a[coef],x,pow);
        	pow--;
        }  printf("(%.1f * %.1f^0) = %.1f\n",a[n-1],x,result);

    } while (1);

    return 0;
}
