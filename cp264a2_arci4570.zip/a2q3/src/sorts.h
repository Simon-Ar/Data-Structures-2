/*
 * sorts.h
 *
 *  Created on: Jan 25, 2019
 *      Author: Simon
 */

#ifndef SORTS_H_
#define SORTS_H_

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void diaplay_array(int , int *);
void copy_array(int, int *, int *);
int is_sorted(int, int *);
void selection_sort(int, int *);
void quick_sort(int, int, int *);
void swap(int *, int *);

void display_array(int n, int *a)
{
  int i;
  for (i=0; i<n; ++i) {
    if (i%10 == 0) printf("\n");
      printf("%3d ", *(a+i));
  }
  printf("\n");
}


void copy_array(int n, int *a, int *b){

	for (int i=0;i<n;i++){
		b[i]=a[i];
	}
}

int is_sorted(int n, int *a) {
	int sorted = 1;
	for (int i=0;i<n-1;i++){
		if (!((a[i]<a[i+1])||(a[i]==a[i+1]))){
			sorted = 0;
		}
	}
	return sorted;
}

void selection_sort(int n, int *a){

	    if(n < 2 || a == NULL){
	        return;
	    }else{
			for(int i = 0; i < n; i++){
				for(int j =i+1;j<n;j++){
					if(a[j] < a[i]){
						swap(&a[i],&a[j]);
				}
			}
	    }
	    }
}

void quick_sort(int m, int n, int *a){
    int pivot;
	int j,i;

     if(m<n){
         pivot=n;
         i=m;
         j=n;

         while(i<j){
             while(a[i]<=a[pivot]&&i<n){
            	 i++;
             }
             while(a[j]>a[pivot]){
            	 j--;
             }
             if(i<j){
                 swap(&a[i],&a[j]);
             }
         }

         swap(&a[pivot],&a[j]);
         quick_sort(m,j-1,a);
         quick_sort(j+1,n,a);
    }
}


void swap(int *first, int *second ){
	int temp;

	temp = *first;
	*first = *second;
	*second = temp;
}

#endif /* SORTS_H_ */
