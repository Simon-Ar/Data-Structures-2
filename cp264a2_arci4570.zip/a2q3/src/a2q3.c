/*
 * a2q3.c
 *
 *  Created on: Jan 25, 2019
 *      Author: Simon
 */
#include "sorts.h"

int main(int argc, char *args[]){
	setbuf(stdout,NULL);
    int n = argc - 1; // number of elements in array to sort
    int a[n];         // original array
    int b[n];         // copy array to sort

    int i = 0;
    for (i = 0; i < n; i++) {
        a[i] = atoi(args[i+1]);

    }
    printf("Array input:");
    display_array(n, a);
    printf("Is sorted:%d\n", is_sorted(n, a));

    printf("Selection sort:");
    copy_array(n, a, b);
    selection_sort(n, b);
    display_array(n, b);
    printf("Is sorted:%d\n", is_sorted(n, b));

    printf("Quick sort:");
    copy_array(n, a, b);
    quick_sort(0, n-1, b);
    display_array(n, b);
    printf("Is sorted:%d\n", is_sorted(n, b));

    //run time measurement
    clock_t t1, t2;
    int m = 1000;
    int a1[m];
    int b1[m];
    //generate randomly an array of m elements more modular m
    srand(time(NULL));
    for (i=0;i<m;i++) {
      a1[i] = rand()% m;
    }

    //run time measuring for selection_sort
    int m1 = 10;
    t1=clock();
    for (i=0; i< m1; i++) {
        copy_array(m, a1, b1);
        selection_sort(m, b1);
        if (is_sorted(m, b1)!=1) printf("not sorted:%d\n",b1);
    }
    t2=clock();
    double time_span1 = (double) t2-t1;
    printf("time_span(selection_sort(%d) for %d times): %0.1f (ms)\n", m, m1, time_span1);

    //run time measuring for quick_sort
    int m2 = 1000;
    t1=clock();
    for (i=0; i< m2; i++) {
        copy_array(m, a1, b1);
        quick_sort(0, m-1, b1);
        if (!is_sorted(m, b1)) printf("not sorted:%d\n");
    }
    t2=clock();
    double time_span2 = (double) t2-t1;
    printf("time_span(quick_sort(%d) for %d times): %0.1f (ms)\n", m, m2, time_span2);

    printf("time_span(selection_sort(%d))/time_span(quick_sort(%d)): %0.1f\n", m, m,
    (time_span1/time_span2)*(m2/m1));

    return 0;
}

