/*
 * bst.c
 *
 *  Created on: Mar. 8, 2019
 *      Author: Simon
 */



#include "bst.h"

TNODE* search(TNODE *root, char *name) {
	while (root) {
		if (*name == root->data)
			return root;
		else if (*name < root->data)
			root = root->left;
		else
			root = root->right;
	}
	return NULL;
}

void insert(TNODE **rootp, char *name, float score) {
	if (*rootp == NULL) {
		*rootp = new_node(*name);
	} else {
		if (*name == (*rootp)->data) {
			return;
		}
		else if (*name < (*rootp)->data)
			return recursive_insert(&(*rootp)->left, name);
		else
			return recursive_insert(&(*rootp)->right, name);
	}
}

void delete(TNODE **rootp, char *name) {
	TNODE *root = *rootp, *tnp;
		if (root == NULL) {
			return;
		}
		else if(*name == root->data ) {
			if(root->left == NULL && root->right == NULL) {
				free(root);
				*rootp = NULL;
			}
			else if (root->left != NULL && root->right == NULL) {
				tnp = root->left;
				free(root);
				*rootp = tnp;
			}
			else if (root->left == NULL && root->right != NULL) {
				tnp = root->right;
				free(root);
				*rootp = tnp;
			}
			else if( root->left!= NULL && root->right != NULL ) {
				tnp = extract_smallest_node(&root->right);
				tnp->left = root->left;
				tnp->right = root->right;
				*rootp = tnp;
				free(root);
			}
			return;
		}
		else {
			if(*name < root->data) {
				return recursive_delete(&root->left, name);
			}
			else {
				return recursive_delete(&root->right, name);
			}
		}
}

TNODE *extract_smallest_node(TNODE **rootp) {
	TNODE *root = *rootp;
	if (root == NULL) {
		return NULL;
	}
	else if (root->left == NULL) {
		*rootp = root->right;
		root->left = NULL;
		root->right = NULL;
		return root;
	}
	else {
		return extract_smallest_node(&root->left);
	}
}

void display_inorder(TNODE *root) {
	if (root) {
		print_inorder(root->left);
		printf("%d ", root->data);
		print_inorder(root->right);
	}
}

void clean_tree(TNODE **rootp) {
	TNODE *root = *rootp;
	if (root) {
		if (root->left)
			clean_tree(&root->left);
		if (root->right)
			clean_tree(&root->right);
		free(root);
	}
	*rootp = NULL;
}
