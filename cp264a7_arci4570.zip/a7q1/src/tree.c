/*
 * tree.c
 *
 *  Created on: Mar. 8, 2019
 *      Author: Simon
 */

#include "tree.h"

TNODE *new_node(int value) {
	TNODE *np = (TNODE *) malloc(sizeof(TNODE));
	if (np == NULL) return NULL;
	np->data = value;
	np->left = NULL;
	np->right = NULL;
	return np;
}

int get_count(TNODE *root) {
	int count =0;
	if (root->left==NULL && root->right==NULL){
		count++;
	}else {
		count = get_count(root->left)+get_count(root->right);
	}
	return count;
}

int get_height(TNODE *root) {
	int count =0;
	if (root->left== NULL){
		if (root->right== NULL){
			return 1;
		}else{
			count = tree_height(root->right);
			count++;
		}
	}else {
		count = tree_height(root->left);
		count++;
	}
	return count;}

void clean_tree(TNODE **rootp) {
	free(*rootp);
}

void display_preorder(TNODE *root) {
	if (root) {
		printf("%d ", root->data);
		print_preorder(root->left);
		print_preorder(root->right);
	}
}

void display_inorder(TNODE *root) {
	if (root) {
		print_inorder(root->left);
		printf("%d ", root->data);
		print_inorder(root->right);
	}
}

void display_postorder(TNODE *root) {
	if (root) {
		print_postorder(root->left);
		print_postorder(root->right);
		printf("%d ", root->data);
	}
}

void iterative_bf_display(TNODE *root) {
	QNODE *q = (QNODE*) malloc(sizeof(QNODE));
	if (root == NULL)
		return;
	enqueue(root,root,root->data);
	while (q) {
		TNODE n  = new_node( dequeue(q,q));
		printf(" " + n.data);
		if (n.left != NULL)
			enqueue(n.left);
		if (n.right != NULL)
			enqueue(n.right);
	}
}

TNODE * iterative_bf_search(TNODE *root, int val) {
	QNODE *q = (QNODE*) malloc(sizeof(QNODE));
	q = root;
	if (root == NULL)
		return NULL;
	enqueue(root,root,root->data);
	while (q) {
		TNODE n  = new_node( dequeue(q,q));
		if (n.data == val){
			return n.data;
		}else{
			if (n.left != NULL)
				enqueue(n.left);
			if (n.right != NULL)
				enqueue(n.right);
		}

	}
}

TNODE *iterative_df_search(TNODE *root, int val) {
	SNODE *s = (SNODE*) malloc(sizeof(SNODE));
	s= root;
	push(s);
	while (s) {
		TNODE *x = pop(s);
		if(x->data == val) return x->data;
		else{
			if(x->right!=NULL) push(x->right);
			if(x->left!=NULL) push(x->left);
		}
	}
}

void display_tree(TNODE *root, int prelen) {
	if (root) {
		int i;
		for (i = 0; i < prelen; i++)
			printf("%c", ' ');
		printf("%s", "|___");
		printf("%c\n", root->data);
		display_tree(root->right, prelen + 4);
		display_tree(root->left, prelen + 4);
	}
}

// queue functions adapted and modified from a6q2
void enqueue(QNODE **frontp, QNODE **rearp, void *pdata) {
	QNODE *qnp = (QNODE*) malloc(sizeof(QNODE));
	if (qnp == NULL) return;
	else {
		qnp->pdata = pdata;
		qnp->next = NULL;

		if (*frontp == NULL) {
			*frontp = qnp;
			*rearp = qnp;
		} else {
			(*rearp)->next = qnp;
			*rearp = qnp;
		}
	}
}
void *dequeue(QNODE **frontp, QNODE **rearp) {
	void *tnp = NULL;
	if (*frontp) {
		QNODE *qnp = *frontp;
		tnp = qnp->pdata;
		if (*frontp == *rearp) {
			*frontp = NULL;
			*rearp = NULL;
		} else {
			*frontp = qnp->next;
		}
		free(qnp);
		return tnp;
	}
	return NULL;
}
void clean_queue(QNODE **frontp, QNODE **rearp) {
	QNODE *temp, *qnp = *frontp;
	while (qnp != NULL) {
		temp = *frontp;
		qnp = qnp->next;
		free(temp);
	}
}

// stack functions adapted and modified from a6q3
void push(SNODE **topp, void *pdata) {
	SNODE *snp = (SNODE*) malloc(sizeof(SNODE));
	snp->pdata = pdata;
	snp->next = NULL;
	if (*topp == NULL) {
		*topp = snp;
	} else {
		snp->next = *topp;
		*topp = snp;
	}
}
void pop(SNODE **topp) {
	if (*topp != NULL) {
		SNODE *snp = *topp;
		*topp = snp->next;
		free(snp);
	}
}
void *peek(SNODE *top) {
	if (top != NULL) {
		return top->pdata;
	}
	return NULL;
}
void clean_stack(SNODE **topp) {
	SNODE *temp, *snp = *topp;
	while (snp) {
		temp = snp;
		snp = snp->next;
		free(temp);
	}
	*topp = NULL;
}
