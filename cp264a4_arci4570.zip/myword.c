/*
 * myword.c
 *
 *  Created on: Feb 6, 2019
 *      Author: Simon
 */

#include "myword.h"

void set_stopword(char *filename, char *stopwords[]){
	FILE *fp = NULL;
	char line[1000];
	char deli[] = ".,\n\t\r";
	char *token;
	int i = 0;

	fp = fopen(filename, "r");
	while (fgets(line,1000,fp)!=NULL){
		token = (char*)strtok(line,deli);
		while (token!=NULL){
			i = (int)(*token - 'a');
			if (*stopwords[i]=='\0')strcat(stopwords[i],",");
			strcat(stopwords[i],token);
			strcat(stopwords[i],",");
			token =(char*)strtok(NULL,deli);
		}
	}
}

// this function check if the word is contained in directory stopwords[]
// returns 1 if yes, 0 otherwise. It use function str_contain_word()
int contain_word(char *stopwords[], char *word){
	return str_contain_word(stopwords[*word-'a'],word);
}

// this function check if word is a word in string str,
// returns 1 if yes, 0 otherwise
int str_contain_word(char *str, char *word){
	if (str == NULL || word == NULL) return 0;
	char temp[20];
	strcat(temp,",");
	strcat(temp,word);
	strcat(temp,",");

	if (strstr(str,temp)) return 1;
	else return 0;
}

int process_word(char *filename, WORDSUMMARY *words, char *stopwords[]){
	const char delimiters[] = " .,;:!()&?-\n\t\r\"\'";
	FILE *fp = NULL;
	char line[MAX_LINE_LEN];
	char *word_token;
	int j =0;
	int i = 0;
	fp = fopen(filename, "r");

	while(fgets(line,MAX_LINE_LEN,fp)!=NULL){
		words->line_count++;
		lower_case(line);
		trim(line);
		word_token = (char*)strtok(line,delimiters);
		while (word_token!=NULL){
			words->word_count++;
			i=0;
			j=0;
			if (contain_word(stopwords,word_token)==0){
				while (words->word_array[j].frequency > 0){
					if (strcmp(words->word_array[j].word, word_token)){
						words->word_array[j].frequency++;
						i++; //keyword found flag
					}
					j++;
				}
				if (i==0){
					strcpy(words->word_array[words->word_count].word,word_token);
					words->word_array[words->word_count].frequency = 1;
					words->keyword_count++;
				}
			}
			word_token = (char*)strtok(NULL,delimiters);
		}
	}
	return 0;
}

int save_to_file(char *filename, WORDSUMMARY *words){
	FILE *fp = NULL;
	fp = fopen(filename, "w");
	int i=0;
	fprintf(fp, "%-20s  %8d\n", "Line count", words->line_count);
	fprintf(fp, "%-20s  %8d\n", "Word count", words->word_count);
	fprintf(fp, "%-20s  %8d\n", "Keyword count", words->keyword_count);
	fprintf(fp, "%-18s  %10s\n", "Keyword", "frequency");
	while (i<words->keyword_count){
		fprintf(fp, "%-20s  %8d\n", words->word_array[i].word, words->word_array[i].frequency);
		i++;
	}
	return 0;
}
