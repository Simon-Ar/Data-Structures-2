/*
 * myrecord.h
 *
 *  Created on: Feb 5, 2019
 *      Author: Simon
 */

#ifndef MYRECORD_H_
#define MYRECORD_H_

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#define MAX_REC 100
#define MAX_LINE 100

typedef struct  {
	char name[20];
	float grade;
} RECORD;

char letter_grade(float s);
int import_data(RECORD dataset[], char *filename);       //return the number of records
void report_data(RECORD dataset[], int n, char *filename); //return status

char letter_grade(float s){
	char grade='\0';

	if (s<=100 && s>=85){
		grade = 'A';
	} else if (s<85 && s>=70){
		grade = 'B';
	} else if (s<70 && s>=60){
		grade = 'C';
	} else if (s<60 && s>=50){
		grade = 'D';
	} else{
		grade = 'F';
	}
	return grade;
}

int import_data(RECORD dataset[], char *filename) {
	FILE *fp = NULL;
	char line[MAX_LINE];
	char comma[] = ",\0";
	int i = 0;

	fp = fopen(filename, "r");

	if (fp!=NULL){
		while (fgets(line,100,fp)!=NULL){
			strncpy(dataset[i].name,strtok(line,comma),20);
			dataset[i].grade = atof(strtok(NULL,comma));
			i++;
		}
	}
	return i;
}

void report_data(RECORD dataset[], int count, char *filename) {
	FILE *fp = NULL;
	float total = 0;
	float mean = 0;
	float var = 0;
	float stndDev = 0;
	int i = 0;

	fp = fopen(filename, "w");

	if (fp!=NULL){
		fprintf(fp,"Letter Grade\n");
		for (i = 0; i<count; i++){
			fprintf(fp,"%-*s%c\n",16,dataset[i].name,letter_grade(dataset[i].grade));
			total += dataset[i].grade;
		}
		mean = total/count;
		for (i=0;i<count;i++){
			var += pow(abs(dataset[i].grade-mean),2);
		}
		var = var/(count-1);
		stndDev = sqrt(var);
		fprintf(fp,"\nSummary\n");
		fprintf(fp,"%-*s%d\n",20,"record count:",count);
		fprintf(fp,"%-*s%.1f\n",20,"average:",mean);
		fprintf(fp,"%-*s%.1f\n",20,"standard deviation:",stndDev);
	}
}

#endif /* MYRECORD_H_ */
