/*
 * mystring.h
 *
 *  Created on: Feb 6, 2019
 *      Author: Simon
 */

#ifndef MYSTRING_H_
#define MYSTRING_H_

#include <stdio.h>

int str_length(char *);
int word_count(char *);
void lower_case(char *);
void trim(char *);


#endif /* MYSTRING_H_ */
